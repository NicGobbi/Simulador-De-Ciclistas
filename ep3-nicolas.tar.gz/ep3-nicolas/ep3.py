from system_manager import SysManager

def main():
  manager = SysManager()
  while True:
    command = input("[ep3]: ")
    if command.split()[0] in manager.action_dict:
      manager.action_dict[command.split()[0]](command.split())
    elif command == 'sai':
      break


if '__main__' == __name__:
  main()