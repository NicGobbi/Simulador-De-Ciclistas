import os

BYTES_PER_BLOCK = 4 * pow(2, 10)
MAX_BYTE_QUANT = 100 * pow(2, 20)
BLOCK_QUANT = MAX_BYTE_QUANT/BYTES_PER_BLOCK
FAT_LAST_POSITION = 99999

BITMAP_BLOCK_QUANT = 7 # bitmap. sao 25600 bytes -> 6.25 blocos aprox 7
FAT_TABLE_BLOCK_QUANT = 32


class SysManager:

  def __init__(self):
    self.action_dict = {
                        'cp': self.cp_action,
                        'mount': self.mount_action,
                        'umount': self.umount_action,
                        'cat': self.cat_action
                      }
  
  def cp_action(self, args):
    if self.fs and args[2]:
      blocks = 0
      first_address = 0
      with open(args[1], 'r') as to_be_copied:
        current_block = to_be_copied.read(BYTES_PER_BLOCK)
        block_address = self.fs.write_block(current_block)
        last_block_address = block_address
        first_address = block_address
        while len(current_block) == BYTES_PER_BLOCK:
          current_block = to_be_copied.read(BYTES_PER_BLOCK)
          block_address = self.fs.write_block(current_block)
          self.fs.fat[last_block_address] = block_address
          last_block_address = block_address
          blocks+=1

        self.fs.fat[block_address] = FAT_LAST_POSITION
        self.fs.dump_bitmap()
        self.fs.dump_fat_table()
      dire = Directory(self.fs.read_block(FAT_TABLE_BLOCK_QUANT + BITMAP_BLOCK_QUANT))
      dire.append_file(args[2][1:], blocks * BYTES_PER_BLOCK, first_address)
      self.fs.dump_dir(dire.dumpable())
    else:
      print('nenhum sistema montado')

  def cat_action(self, args):
    dire = Directory(self.fs.read_block(FAT_TABLE_BLOCK_QUANT + BITMAP_BLOCK_QUANT))
    first_address = -1
    for elem in dire.files:
      if elem['name'].strip() == args[1][1:]:
        first_address = int(elem['location'])
        break
    if first_address == -1:
      exit('arquivo inexistente')
    address = self.fs.fat[first_address]
    print(self.fs.read_block(address), end='')
    while address != FAT_LAST_POSITION:
      print(self.fs.read_block(address), end='')
      address = self.fs.fat[address]
    print('')

  def mount_action(self, args):
    if os.path.isfile(args[1]):
      self.fs = FileSystem(open(args[1], 'r+'))
      self.fs.load()
    else:
      open(args[1], 'w+')
      self.fs = FileSystem(open(args[1], 'r+'))
      self.fs.initialize()

  def umount_action(self, args):
    del self.fs


class FileSystem:

  def __init__(self, file):
    self.file = file
    self.fat = []
    self.bitmap = []

  def initialize(self):
    self.file.write(BITMAP_BLOCK_QUANT * BYTES_PER_BLOCK * '1')
    self.file.write(FAT_TABLE_BLOCK_QUANT * BYTES_PER_BLOCK * '0')
    self.file.write(BYTES_PER_BLOCK * '\x00')
    self.load()
    for i in range(FAT_TABLE_BLOCK_QUANT + BITMAP_BLOCK_QUANT + 1):  # mais um por conta do root /
      self.bitmap[i] = 0
    self.dump_bitmap()

  def load(self):
    # carregando bitmap na memoria
    for i in range(BITMAP_BLOCK_QUANT):
      temp = self.read_block(i)
      for j in range(BYTES_PER_BLOCK):
        self.bitmap.append(int(temp[j]))
    
    # carregando tabela fat na memoria
    for i in range(BITMAP_BLOCK_QUANT, FAT_TABLE_BLOCK_QUANT + BITMAP_BLOCK_QUANT):
      temp = self.read_block(i)
      for j in range(0, BYTES_PER_BLOCK - 1, 5):
        self.fat.append(int(temp[j:j + 5]))
    
    temp = self.read_block(FAT_TABLE_BLOCK_QUANT + BITMAP_BLOCK_QUANT)

  def dump_dir(self, contents):
    self.goto_block(FAT_TABLE_BLOCK_QUANT + BITMAP_BLOCK_QUANT)
    self.file.write(contents)

  def dump_bitmap(self):
    self.goto_block(0)
    for i in self.bitmap:
      self.file.write(str(i))

  def dump_fat_table(self):
    self.goto_block(BITMAP_BLOCK_QUANT)
    for i in self.fat:
      self.file.write('0' * (5 - len(str(i))) + str(i))

  def read_block(self, address):
    self.goto_block(address)
    return self.file.read(BYTES_PER_BLOCK)

  def write_block(self, content):
    if len(content) <= BYTES_PER_BLOCK:
      free_block_address = -1
      for index, i in enumerate(self.bitmap):
        if index > BLOCK_QUANT:
          exit('O sistema nao possui mais espaco livre')
        if i == 1:
          free_block_address = index
          break
      self.goto_block(free_block_address)
      self.file.write(content)
      self.bitmap[free_block_address] = 0
      return free_block_address
    else:
      exit('O conteudo do bloco e menor do que o necessario')

  def goto_block(self, address):
    if address < BLOCK_QUANT:
      self.file.seek(address * BYTES_PER_BLOCK, 0)
    else:
      exit(f'O sistema esta tentando acessar um bloco invalido. (MAX_ADRESS = {BLOCK_QUANT - 1}) address = {address}')
  
  def __del__(self):
    self.file.close()
  
      
class Directory:

  def __init__(self, contents):
    self.files = []
    for i in range(BYTES_PER_BLOCK):
      if contents[i] == '\x00':
        break
    contents = contents[0:i]
    current_file = contents[0:44]
    acc = 0
    while(len(current_file) != 0):
      obj = {}
      obj['name'] = current_file[0:30]
      obj['size'] = current_file[30:39]
      obj['location'] = current_file[39:44]
      self.files.append(obj)
      acc += 44
      current_file = contents[0 + acc:44 + acc]

  def append_file(self, file_name, size, location):
    if(len(file_name) > 30):
      exit('O nome do arquivo deve ser menor ou igual a 30')
    self.files.append({'name': ' ' * (30 - len(str(file_name))) + str(file_name), 'size': '0' * (9 - len(str(size))) + str(size), 'location': '0' * (5 - len(str(location))) + str(location)})

  def dumpable(self):
    return ''.join([x['name'] + x['size'] + x['location'] for x in self.files])
